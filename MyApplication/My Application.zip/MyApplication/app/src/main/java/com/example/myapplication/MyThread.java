package com.example.myapplication;

import static androidx.core.content.PermissionChecker.checkSelfPermission;

import android.Manifest;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class MyThread extends Thread{

    String filepath;
    Handler handler;
    private static final String SERVER_ADDRESS = "192.168.1.3";
    private static final int PORT = 600;


    public MyThread(String filepath, Handler handler){
        this.filepath = filepath+"/route1.gpx";
        this.handler = handler;
    }



    @Override
    public void run() {
        try {

            //Message msg = new Message();
            // Bundle bundle = new Bundle();
            //bundle.putString("result","Sent: "+arg);
            //msg.setData(bundle);


            // handler.sendMessage(msg);

            try {
                Log.d("myTag", "about to connect");
                Socket socket = null;
                try {
                    socket = new Socket(SERVER_ADDRESS, PORT);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                Log.d("myTag", "connnected");

                File file = new File(this.filepath);
                try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        Log.e("PRINTING,", " PAPA: "+ line);
                        // System.out.println(line);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Log.e("KANONISE NA IPARXEIS","FINGERMASTER: "+this.filepath.trim());
                Log.e("KANONISE NA IPARXEIS","FINGERMASTER: "+file.exists());
                FileInputStream fileInput = new FileInputStream(file);
                byte[] fileData = new byte[(int) file.length()];
                fileInput.read(fileData);
                fileInput.close();
                String fileString = new String(fileData, StandardCharsets.UTF_8);

                // Write the file data to the server's output stream
                OutputStream outputStream = socket.getOutputStream();

                PrintWriter out = new PrintWriter(new OutputStreamWriter(outputStream, StandardCharsets.UTF_8), true);
                out.println(fileString);

                ObjectInputStream in = new ObjectInputStream(socket.getInputStream());

                //outputStream.close(); // close connection with master
                socket.close();

            } catch (RuntimeException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }}}